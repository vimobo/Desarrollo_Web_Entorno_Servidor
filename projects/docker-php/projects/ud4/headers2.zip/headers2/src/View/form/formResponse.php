


<p>
    <?= $id ?>
</p>
<p>
    <?= $nombre ?>
</p>
<p>
    <?= $precio ?>
</p>
<p>
    <?= $descripcion ?>
</p>